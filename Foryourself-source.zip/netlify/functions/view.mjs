import { getStore } from "@netlify/blobs";
const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const safeInline = new Set(["image/jpeg","image/png","image/gif","image/webp","image/avif","audio/mpeg","audio/mp3","audio/wav","audio/x-wav","audio/ogg","audio/mp4","audio/aac","video/mp4","video/webm","video/ogg","application/pdf","text/plain","text/markdown"]);
export const handler = async (event) => {
  const id = (event.path || "").split("/").filter(Boolean).at(-1) || "";
  if (!/^[0-9a-f-]{36}$/i.test(id)) return { statusCode: 404, headers: { "content-type": "text/html; charset=utf-8" }, body: "Karya tidak ditemukan." };
  try {
    const store = getStore("aurora-records-v1");
    const item = await store.get(`meta:${id}`, { type: "json" });
    if (!item) return { statusCode: 404, headers: { "content-type": "text/html; charset=utf-8" }, body: "Karya tidak ditemukan." };
    const asset = `/api/file/${encodeURIComponent(id)}`;
    const mime = safeInline.has(item.mime) ? item.mime : "";
    let media = "";
    if (item.kind === "Audio" && mime.startsWith("audio/")) media = `<audio controls preload="metadata" src="${asset}"></audio>`;
    else if (item.kind === "Video" && mime.startsWith("video/")) media = `<video controls playsinline preload="metadata" src="${asset}"></video>`;
    else if (item.kind === "Gambar" && mime.startsWith("image/")) media = `<img src="${asset}" alt="${esc(item.title)}">`;
    else if (item.size && mime) media = `<p><a class="download" href="${asset}" download>Unduh lampiran: ${esc(item.fileName)}</a></p>`;
    else if (item.size) media = `<p>Lampiran tersedia dengan tautan unduh.</p>`;
    const html = `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#e5e5e5"><title>${esc(item.title)} — Aurora</title><meta name="description" content="${esc(item.description || "Karya dari koleksi Aurora.")}"><style>*{box-sizing:border-box}body{margin:0;background:#e5e5e5;color:#242424;font:16px system-ui,sans-serif}.wrap{max-width:900px;margin:auto;padding:28px 22px}.brand{display:flex;align-items:center;gap:10px;font-weight:700}.mark{display:grid;place-items:center;background:#c75d37;color:white;width:34px;height:34px;border-radius:10px}.card{background:#f6f6f6;border:1px solid #cecece;border-radius:16px;margin-top:42px;overflow:hidden}.content{padding:clamp(22px,5vw,48px)}.eyebrow{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#c75d37;font-weight:700}.title{font:600 clamp(34px,7vw,60px)/1.05 Georgia,serif;margin:12px 0}.desc{color:#696969;line-height:1.7;white-space:pre-wrap}.meta{color:#777;font-size:12px;margin:22px 0}.media{background:#d5d5d5;display:grid;place-items:center;padding:18px;min-height:180px}.media img,.media video{display:block;max-width:100%;max-height:70vh;border-radius:8px}.media audio{width:min(650px,100%)}a{color:#9b4328}.foot{color:#777;font-size:12px;margin:24px 0}</style></head><body><main class="wrap"><a href="/" style="color:inherit;text-decoration:none"><div class="brand"><span class="mark">A</span>Aurora</div></a><article class="card"><div class="content"><div class="eyebrow">Koleksi · bagi gua sendiri</div><h1 class="title">${esc(item.title)}</h1><div class="desc">${esc(item.description || "Karya dari koleksi Aurora.")}</div><div class="meta">${esc(item.kind)} · ${new Date(item.created).toLocaleDateString("id-ID", { day:"numeric", month:"long", year:"numeric" })}</div></div>${media ? `<div class="media">${media}</div>` : ""}</article><p class="foot">Dibagikan dari Aurora · <a href="/">Lihat koleksi</a></p></main></body></html>`;
    return { statusCode: 200, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=60", "x-content-type-options": "nosniff", "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; img-src 'self'; media-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'" }, body: html };
  } catch (error) {
    console.error("Aurora viewer error:", error);
    return { statusCode: 500, headers: { "content-type": "text/plain; charset=utf-8" }, body: "Halaman karya sedang tidak tersedia." };
  }
};
