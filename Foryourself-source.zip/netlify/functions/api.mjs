import { getStore } from "@netlify/blobs";

const records = () => getStore("aurora-records-v1");
const files = () => getStore("aurora-files-v1");
const MAX_BYTES = 4 * 1024 * 1024;
const safeMime = new Set([
  "image/jpeg", "image/png", "image/gif", "image/webp", "image/avif",
  "audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav", "audio/ogg", "audio/mp4", "audio/aac",
  "video/mp4", "video/webm", "video/ogg", "application/pdf", "text/plain", "text/markdown",
  "application/zip", "application/octet-stream"
]);
const inlineMime = new Set([
  "image/jpeg", "image/png", "image/gif", "image/webp", "image/avif",
  "audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav", "audio/ogg", "audio/mp4", "audio/aac",
  "video/mp4", "video/webm", "video/ogg", "application/pdf", "text/plain", "text/markdown"
]);
const json = (data, status = 200) => ({
  statusCode: status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" },
  body: JSON.stringify(data)
});
const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function getId(path) { return path.split("/").filter(Boolean).at(-1) || ""; }
function authorized(event) {
  const expected = process.env.AURORA_UPLOAD_KEY;
  const got = event.headers?.authorization || event.headers?.Authorization || "";
  return Boolean(expected && got === `Bearer ${expected}`);
}
function publicUrl(event, path) {
  const host = event.headers?.["x-forwarded-host"] || event.headers?.host || "foryourself.netlify.app";
  const proto = event.headers?.["x-forwarded-proto"] || "https";
  return `${proto}://${host}${path}`;
}

export const handler = async (event) => {
  try {
    const path = event.path || "";
    const method = event.httpMethod || "GET";

    if (path.endsWith("/health") && method === "GET") return json({ ok: true, service: "Aurora" });

    if (path.endsWith("/list") && method === "GET") {
      const { blobs } = await records().list({ prefix: "meta:" });
      const items = await Promise.all(blobs.map(b => records().get(b.key, { type: "json" })));
      return json(items.filter(Boolean).sort((a, b) => b.created - a.created));
    }

    if (path.endsWith("/upload") && method === "POST") {
      if (!authorized(event)) return json({ error: "Kunci unggah salah atau belum disetel." }, 401);
      const isJson = (event.headers?.["content-type"] || "").includes("application/json");
      let title, description, kind, fileName, mime, buffer = null;
      if (isJson) {
        if ((event.body || "").length > 12000) return json({ error: "Informasi karya terlalu panjang." }, 413);
        const body = JSON.parse(event.body || "{}");
        title = body.title; description = body.description || ""; kind = body.kind || "Tulisan";
      } else {
        title = decodeURIComponent(event.headers?.["x-aurora-title"] || "");
        description = decodeURIComponent(event.headers?.["x-aurora-description"] || "");
        kind = decodeURIComponent(event.headers?.["x-aurora-kind"] || "Lainnya");
        fileName = decodeURIComponent(event.headers?.["x-aurora-filename"] || "karya");
        mime = (event.headers?.["content-type"] || "application/octet-stream").split(";")[0].toLowerCase();
        if (!event.body) return json({ error: "File kosong atau gagal dibaca." }, 400);
        buffer = Buffer.from(event.body, event.isBase64Encoded ? "base64" : "utf8");
        if (buffer.length > MAX_BYTES) return json({ error: "Ukuran file maksimal 4 MB per karya pada paket ini." }, 413);
      }
      title = String(title || "").trim().slice(0, 100);
      description = String(description || "").trim().slice(0, 500);
      if (!title) return json({ error: "Judul karya wajib diisi." }, 400);
      const id = crypto.randomUUID();
      const record = { id, title, description, kind: String(kind).slice(0, 30), fileName: fileName ? String(fileName).split(/[\\/]/).pop().slice(0, 180) : "", mime: safeMime.has(mime) ? mime : "application/octet-stream", size: buffer?.length || 0, created: Date.now() };
      if (buffer) {
        const binary = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
        await files().set(`file:${id}`, binary);
      }
      try { await records().setJSON(`meta:${id}`, record); }
      catch (error) { if (buffer) await files().delete(`file:${id}`); throw error; }
      return json({ item: record, shareUrl: publicUrl(event, `/karya/${id}`) }, 201);
    }

    if (path.includes("/file/") && method === "GET") {
      const id = getId(path);
      const record = await records().get(`meta:${id}`, { type: "json" });
      if (!record) return json({ error: "Karya tidak ditemukan." }, 404);
      const data = await files().get(`file:${id}`, { type: "arrayBuffer" });
      if (!data) return json({ error: "Lampiran tidak ditemukan." }, 404);
      const mime = safeMime.has(record.mime) ? record.mime : "application/octet-stream";
      const disposition = inlineMime.has(mime) ? "inline" : "attachment";
      const name = encodeURIComponent(record.fileName || "karya");
      return {
        statusCode: 200,
        isBase64Encoded: true,
        headers: {
          "content-type": mime,
          "content-length": String(data.byteLength),
          "content-disposition": `${disposition}; filename*=UTF-8''${name}`,
          "cache-control": "public, max-age=3600",
          "x-content-type-options": "nosniff",
          "content-security-policy": "default-src 'none'; sandbox"
        },
        body: Buffer.from(data).toString("base64")
      };
    }

    if (path.includes("/item/") && method === "DELETE") {
      if (!authorized(event)) return json({ error: "Kunci unggah salah atau belum disetel." }, 401);
      const id = getId(path);
      await records().delete(`meta:${id}`);
      await files().delete(`file:${id}`);
      return json({ ok: true });
    }

    return json({ error: "Rute tidak ditemukan." }, 404);
  } catch (error) {
    console.error("Aurora API error:", error);
    return json({ error: "Terjadi kesalahan saat memproses permintaan. Coba lagi." }, 500);
  }
};
