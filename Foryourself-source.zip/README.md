# Aurora — koleksi personal

Aurora menyimpan karya di Netlify Blobs dan menyediakan halaman berbagi unik `/karya/:id`. Unggahan dan penghapusan memerlukan kunci pemilik; pengunjung dapat membuka halaman karya tanpa login.

## Menyiapkan Netlify

1. Hubungkan repositori ini ke situs Netlify `foryourself` dan pilih branch `main`.
2. Di Netlify **Site configuration → Environment variables**, tambahkan `AURORA_UPLOAD_KEY` dengan nilai rahasia panjang pilihan Anda. Jangan menyimpan kunci di repo atau kode browser.
3. Pastikan Netlify membaca `netlify.toml` di root. Publish directory: `public`; Functions directory: `netlify/functions`.
4. Deploy branch `main`. Netlify akan membangun dan memasang Functions bersama situs.

File berukuran maksimal 4 MB per karya pada implementasi ini. Format yang tidak dapat diputar langsung tetap tersedia sebagai unduhan. Penyimpanan memakai Netlify Blobs dan mengikuti kuota/paket akun Netlify.

Panduan pemilik lebih rinci: [PANDUAN.md](PANDUAN.md).
