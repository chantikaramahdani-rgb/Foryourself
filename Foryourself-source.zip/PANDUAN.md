# Aurora — panduan pasang manual di Netlify

Paket ini menambahkan penyimpanan online, unggah karya dengan kunci pemilik, dan tautan unik seperti `https://foryourself.netlify.app/karya/ID-KARYA`. Pengunjung dapat membuka tautan dan melihat atau memutar karya yang sesuai. File maksimum 4 MB per karya pada paket ini; file yang formatnya tidak umum tersedia sebagai unduhan. Upload video berukuran besar membutuhkan penyimpanan unggahan langsung (direct upload) yang berbeda.

## Sebelum mulai

1. Pastikan bisa masuk ke akun Netlify yang mengelola `foryourself.netlify.app`.
2. Pasang Node.js versi 20 atau yang lebih baru di komputer. Situsnya tidak diubah sampai Anda menjalankan langkah deploy terakhir.
3. Unduh dan ekstrak ZIP paket Aurora ke satu folder di komputer.

## 1. Buat kunci pemilik

Buat kata sandi panjang dan unik dengan pengelola kata sandi. Kunci ini dipakai hanya oleh pemilik untuk mengunggah dan menghapus karya; jangan kirim atau tulis di halaman publik.

Buka Netlify, pilih situs **foryourself**, lalu masuk ke **Site configuration → Environment variables**. Tambahkan variabel:

- Key: `AURORA_UPLOAD_KEY`
- Value: kunci rahasia yang baru dibuat

Simpan perubahan. Jangan taruh kunci ini di file HTML atau kirim di chat.

## 2. Hubungkan folder ke situs yang sudah ada

Buka Terminal/PowerShell di folder hasil ekstrak (folder yang berisi `netlify.toml`), lalu jalankan:

```bash
npm install
npx netlify login
npx netlify link
```

Saat diminta memilih situs, pilih situs yang sudah ada: **foryourself**. Perintah `netlify link` hanya menghubungkan folder lokal ke situs; belum mengganti halaman publik.

## 3. Terbitkan pembaruan

Di folder yang sama, jalankan:

```bash
npx netlify deploy --prod
```

Tunggu sampai Netlify melaporkan deploy berhasil. Buka `https://foryourself.netlify.app` dan muat ulang halaman. Jika Anda memasang kunci setelah deploy pertama, deploy ulang setelah menyimpan variabel.

## 4. Coba berbagi karya

1. Tekan **Tambah karya**.
2. Pilih karya. Batas file pada paket ini adalah **4 MB per karya**. Bisa juga menyimpan tulisan tanpa lampiran.
3. Masukkan kunci pemilik saat diminta, lalu simpan.
4. Tekan **Salin tautan** pada kartu karya. Bagikan tautannya ke orang yang ingin melihatnya.
5. Coba buka tautan tersebut di jendela privat atau perangkat lain untuk memastikan halaman karya muncul.

Orang yang memiliki tautan dapat melihat karya. Jangan unggah materi yang ingin tetap rahasia. Karya yang sebelumnya hanya ada di penyimpanan browser lama **tidak otomatis ikut pindah**; unggah kembali setelah versi baru aktif. Penyimpanan Netlify Blobs bersifat persisten di seluruh deploy situs, tetapi penggunaan/kuota mengikuti akun Netlify Anda.

## Jika ada masalah

- **Kunci salah/belum disetel:** periksa `AURORA_UPLOAD_KEY` pada Environment variables. Setelah mengubahnya, jalankan deploy lagi.
- **Tautan API tidak ditemukan:** pastikan deploy dijalankan dari folder yang memiliki `netlify.toml` dan subfolder `netlify/functions`.
- **File terlalu besar:** kurangi ukuran file sampai di bawah 4 MB. Batas function Netlify menghalangi upload berkas besar dengan cara langsung ini; untuk video besar perlu layanan penyimpanan yang menerima upload langsung.
- **Mau membatalkan:** pilih deploy sebelumnya di Netlify Deploys lalu publikasikan kembali versi sebelumnya.

Rujukan resmi: [Netlify Blobs](https://docs.netlify.com/build/data-and-storage/netlify-blobs/), [Netlify Functions](https://docs.netlify.com/build/functions/overview/), dan [Netlify CLI](https://docs.netlify.com/api-and-cli-guides/cli-guides/get-started-with-cli/).
